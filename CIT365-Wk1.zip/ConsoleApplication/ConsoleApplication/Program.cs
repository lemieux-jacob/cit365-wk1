﻿using System;

namespace ConsoleApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            // (My Code)

            // Initialize Variables
            string name, state;
            DateTime today, christmas;

            // Assign appropriate "name" & "state" values.
            name = "Jacob Lemieux";
            state = "Pennsylvania";

            // Prepare Date Variables
            today = DateTime.Today;
            christmas = new DateTime(today.Year, 12, 25);

            // If Christmas is past for this year calculate for next year.
            if (christmas < today)
                christmas.AddYears(1);

            // Output
            Console.WriteLine($"My name is {name}.");
            Console.WriteLine($"I live in {state}.");
            Console.WriteLine($"The Date is: {DateTime.Now.ToString("MM/dd/yyyy")}");
            Console.WriteLine($"There are {(christmas - today).Days} until Christmas");

            // (Example Code)

            // Initialize Variables
            double width, height, woodLength, glassArea;
            string widthStr, heightStr;

            // Prompt the User for Input
            Console.WriteLine($"Calculate the amount of wood and glass required to make a window.\nPlease enter the desired dimensions.");
            Console.WriteLine("Width (ft)?: ");
            // Wait for Input (Width)
            widthStr = Console.ReadLine();
            // Parse String to Double
            width = double.Parse(widthStr);

            // Prompt the User for Input
            Console.WriteLine("Height (ft)?: ");
            // Wait for Input (Height)
            heightStr = Console.ReadLine();
            // Parse String to Double
            height = double.Parse(heightStr);

            // Logic
            woodLength = 2 * (width + height) * 3.25;
            glassArea = 2 * (width * height);

            // Output
            Console.WriteLine($"The length of the wood is {woodLength} feet.");
            Console.WriteLine($"The area of teh glass is {glassArea} square metres.");

            // Pause the Application
            Console.WriteLine("Press any key to continue...");
            Console.ReadKey();
        }
    }
}
